/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "bb167dc36dc7d69d942bc956a47a47ce"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0ddafa6d95074851c29d035e3b699f0a"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b0310d41f19a371145594709ab266313"
  }, {
    "url": "index.html",
    "revision": "72851e5bc54b19da2993c2366c0fc6e8"
  }, {
    "url": "icon.svg",
    "revision": "9b479ff89885dbf8b622bc49846532cb"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "e4dc006ada0828a5c7a12fffe46d36f2"
  }, {
    "url": "audio/song_week_days.wav",
    "revision": "5f8c706600f2b6781d67eac0844b08bc"
  }, {
    "url": "audio/song_shapes.wav",
    "revision": "8c0c54715f27198cea74fe37b1407279"
  }, {
    "url": "audio/song_school.wav",
    "revision": "fcb164120b313ff35255d6f09ea91d4f"
  }, {
    "url": "audio/song_parents.wav",
    "revision": "70593f0db7fcf4beb81740cec717d72a"
  }, {
    "url": "audio/song_numbers.wav",
    "revision": "2dcf65adcedfea236ba1963d02724ac7"
  }, {
    "url": "audio/song_islamic_pillars.wav",
    "revision": "ce0c3f893a35d1a65ab0723ee479ba41"
  }, {
    "url": "audio/song_colors.wav",
    "revision": "90246050579f762a64146a429e10c76c"
  }, {
    "url": "audio/song_cleanliness.wav",
    "revision": "a7a044defe2fc7f6cb064291de2f59e8"
  }, {
    "url": "audio/song_animals.wav",
    "revision": "54635801eabf1da7161007ab39911086"
  }, {
    "url": "audio/song_alphabet.wav",
    "revision": "cfcb654e3d8f91a5ac5bfd5f888a6e01"
  }, {
    "url": "assets/index-DTdWFC1i.css",
    "revision": null
  }, {
    "url": "assets/index-BnY-8L4f.js",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_________-_______c2678673.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_________-_______a3361e2a.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_________-_______37c3253a.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_________-_______268986d7.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_________-_______1e77b031.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "e4dc006ada0828a5c7a12fffe46d36f2"
  }, {
    "url": "icon.svg",
    "revision": "9b479ff89885dbf8b622bc49846532cb"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b0310d41f19a371145594709ab266313"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0ddafa6d95074851c29d035e3b699f0a"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "bb167dc36dc7d69d942bc956a47a47ce"
  }, {
    "url": "manifest.webmanifest",
    "revision": "bb72c80969d9ef26262ebf74847c41f9"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
