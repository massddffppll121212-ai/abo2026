عالم أكرم - حزمة التطبيق الكاملة وبناء Android APK

1. لبناء ملف APK تلقائياً على GitHub Actions (بدون مفاتيح توقيع):
   - ارفع المشروع إلى مستودع GitHub.
   - تأكد من وجود ملف: .github/workflows/android.yml
   - افتح تبويب Actions في GitHub وشغل Build Android APK.
   - حمل ملف AkramWorld-Debug-APK أو AkramWorld-Unsigned-Release-APK مباشرة إلى هاتفك.

2. لبناء APK عبر الكمبيوتر (Capacitor + Android Studio):
   - فك ضغط الملف وادخل إلى مجلد android-ready
   - نفذ: npm install && npx cap add android && npx cap open android
